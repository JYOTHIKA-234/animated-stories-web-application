function playSelectedParagraph() {
    // Get the selected paragraph text
    var selectedText = window.getSelection().toString().trim();
    
    // If no text is selected, return
    if (!selectedText) {
      return;
    }
  
    // Construct the TTS API URL with the selected text
    var ttsUrl = 'radhakrishna 3d 2.html' + encodeURIComponent(selectedText);
  
    // Create an Audio element
    var audioElement = new Audio(ttsUrl);
  
    // Play the audio
    audioElement.play();
  }
  
  // Attach a click event listener to the document
  document.addEventListener('click', function(event) {
    // Check if the clicked element is a paragraph
    if (event.target.nodeName === 'P') {
      // Play the selected paragraph
      playSelectedParagraph();
    }
  });
  